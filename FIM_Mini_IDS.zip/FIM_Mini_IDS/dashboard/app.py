from flask import Flask, render_template_string
from pathlib import Path
import sys


# --------------------------------------------------
# Project paths
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent

sys.path.insert(0, str(PROJECT_ROOT / "src"))

from monitor import load_baseline, scan_current_files


LOG_FILE = PROJECT_ROOT / "logs" / "fim_events.log"


app = Flask(__name__)

def read_log_events():
    """
    Read timestamped FIM events from the security log.
    """

    if not LOG_FILE.exists():
        return []

    with open(LOG_FILE, "r", encoding="utf-8") as file:
        lines = file.readlines()

    events = []

    for line in lines:
        line = line.strip()

        if line:
            parts = line.split(" | ", 2)

            if len(parts) == 3:
                timestamp, level, message = parts

                events.append({
                    "timestamp": timestamp,
                    "level": level,
                    "message": message
                })

    return events

# --------------------------------------------------
# Dashboard HTML
# --------------------------------------------------

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>FIM Mini IDS Dashboard</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 5px;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        .cards {
            display: grid;
            grid-template-columns:
                repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);
        }

        .card h2 {
            margin: 0;
            font-size: 32px;
        }

        .card p {
            color: #666;
            margin-bottom: 0;
        }

        .section {
            background: white;
            padding: 25px;
            margin-bottom: 25px;
            border-radius: 10px;
            box-shadow:
                0 2px 8px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f0f2f4;
        }

        .modified {
            font-weight: bold;
        }

        .new {
            font-weight: bold;
        }

        .deleted {
            font-weight: bold;
        }

        .clean {
            font-weight: bold;
        }

        .footer {
            text-align: center;
            color: #777;
            margin-top: 30px;
        }

    </style>

</head>


<body>

<div class="container">

    <h1>File Integrity Monitoring System</h1>

    <div class="subtitle">
        Mini Host-Based Intrusion Detection System
    </div>


    <!-- Summary cards -->

    <div class="cards">

        <div class="card">
            <h2>{{ total_files }}</h2>
            <p>Baseline Files</p>
        </div>

        <div class="card">
            <h2>{{ modified_count }}</h2>
            <p>Modified</p>
        </div>

        <div class="card">
            <h2>{{ new_count }}</h2>
            <p>New Files</p>
        </div>

        <div class="card">
            <h2>{{ deleted_count }}</h2>
            <p>Deleted</p>
        </div>

    </div>


    <!-- Detection results -->

    <div class="section">

        <h2>Current Integrity Status</h2>

        {% if modified_files %}

            <h3>Modified Files</h3>

            <table>

                <tr>
                    <th>File</th>
                    <th>Status</th>
                </tr>

                {% for file in modified_files %}

                <tr>
                    <td>{{ file }}</td>
                    <td class="modified">
                        MODIFIED
                    </td>
                </tr>

                {% endfor %}

            </table>

        {% endif %}


        {% if new_files %}

            <h3>New Files</h3>

            <table>

                <tr>
                    <th>File</th>
                    <th>Status</th>
                </tr>

                {% for file in new_files %}

                <tr>
                    <td>{{ file }}</td>
                    <td class="new">
                        NEW
                    </td>
                </tr>

                {% endfor %}

            </table>

        {% endif %}


        {% if deleted_files %}

            <h3>Deleted Files</h3>

            <table>

                <tr>
                    <th>File</th>
                    <th>Status</th>
                </tr>

                {% for file in deleted_files %}

                <tr>
                    <td>{{ file }}</td>
                    <td class="deleted">
                        DELETED
                    </td>
                </tr>

                {% endfor %}

            </table>

        {% endif %}


        {% if not modified_files
              and not new_files
              and not deleted_files %}

            <p class="clean">
                No integrity changes detected.
            </p>

        {% endif %}

    </div>


    <!-- Baseline files -->

    <div class="section">

        <h2>Trusted Baseline</h2>

        <table>

            <tr>
                <th>File</th>
                <th>SHA-256 Hash</th>
            </tr>

            {% for file, details in baseline.items() %}

            <tr>

                <td>{{ file }}</td>

                <td>
                    {{ details["sha256"] }}
                </td>

            </tr>

            {% endfor %}

        </table>

    </div>

    <div class="section">

        <h2>Security Event Log</h2>

        <table>

            <tr>
                <th>Timestamp</th>
                <th>Level</th>
                <th>Event</th>
            </tr>

            {% for event in events %}

            <tr>
                <td>{{ event["timestamp"] }}</td>
                <td>{{ event["level"] }}</td>
                <td>{{ event["message"] }}</td>
            </tr>

            {% endfor %}

        </table>

    </div>

    <div class="footer">

        FIM Mini IDS — Controlled Research Prototype

    </div>

</div>

</body>

</html>
"""


# --------------------------------------------------
# Dashboard route
# --------------------------------------------------

@app.route("/")
def dashboard():

    baseline = load_baseline()
    current_files = scan_current_files()
    events = read_log_events()

    baseline_files = set(baseline.keys())
    current_file_names = set(current_files.keys())


    # Detect modified files

    modified_files = []

    for file_name in baseline_files & current_file_names:

        if (
            baseline[file_name]["sha256"]
            != current_files[file_name]["sha256"]
        ):

            modified_files.append(file_name)


    # Detect new files

    new_files = list(
        current_file_names - baseline_files
    )


    # Detect deleted files

    deleted_files = list(
        baseline_files - current_file_names
    )


    return render_template_string(
        HTML_TEMPLATE,

        baseline=baseline,
        events=events,

        total_files=len(baseline),

        modified_files=modified_files,
        modified_count=len(modified_files),

        new_files=new_files,
        new_count=len(new_files),

        deleted_files=deleted_files,
        deleted_count=len(deleted_files)
    )


# --------------------------------------------------
# Run Flask
# --------------------------------------------------

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )