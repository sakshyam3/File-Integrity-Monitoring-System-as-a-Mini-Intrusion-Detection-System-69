from pathlib import Path
import sys

# Get the project root
PROJECT_ROOT = Path(__file__).resolve().parent

# Add src folder to Python path
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from monitor import detect_changes


def main():
    print("=" * 60)
    print("FILE INTEGRITY MONITORING SYSTEM")
    print("=" * 60)
    print("Starting integrity check...")
    print()

    detect_changes()

    print()
    print("Integrity check completed.")
    print("=" * 60)


if __name__ == "__main__":
    main()