import time
import statistics
from pathlib import Path
import sys


# --------------------------------------------------
# Project configuration
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent

sys.path.insert(0, str(PROJECT_ROOT / "src"))

from monitor import detect_changes, scan_current_files


# --------------------------------------------------
# Performance test
# --------------------------------------------------

def run_performance_test(runs=10):

    print("=" * 60)
    print("FIM PERFORMANCE TEST")
    print("=" * 60)

    print(f"Number of test runs: {runs}")
    print()

    file_count = len(scan_current_files())

    print(f"Files currently scanned: {file_count}")
    print()

    execution_times = []

    for run_number in range(1, runs + 1):

        start_time = time.perf_counter()

        detect_changes()

        end_time = time.perf_counter()

        elapsed = end_time - start_time

        execution_times.append(elapsed)

        print(
            f"Run {run_number:02d}: "
            f"{elapsed:.6f} seconds"
        )

    average_time = statistics.mean(execution_times)
    minimum_time = min(execution_times)
    maximum_time = max(execution_times)

    print()
    print("=" * 60)
    print("PERFORMANCE RESULTS")
    print("=" * 60)

    print(
        f"Average execution time: "
        f"{average_time:.6f} seconds"
    )

    print(
        f"Minimum execution time: "
        f"{minimum_time:.6f} seconds"
    )

    print(
        f"Maximum execution time: "
        f"{maximum_time:.6f} seconds"
    )

    print("=" * 60)


if __name__ == "__main__":
    run_performance_test()