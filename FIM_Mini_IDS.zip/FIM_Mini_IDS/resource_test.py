import time
import statistics
import os
import psutil
from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parent

sys.path.insert(0, str(PROJECT_ROOT / "src"))

from monitor import detect_changes, scan_current_files


def run_resource_test(runs=10):

    print("=" * 60)
    print("FIM RESOURCE USAGE TEST")
    print("=" * 60)

    process = psutil.Process(os.getpid())

    file_count = len(scan_current_files())

    print(f"Files currently scanned: {file_count}")
    print(f"Number of test runs: {runs}")
    print()

    memory_usage = []
    cpu_usage = []

    for run_number in range(1, runs + 1):

        process.cpu_percent(None)

        start_memory = process.memory_info().rss / (1024 * 1024)

        start_time = time.perf_counter()

        detect_changes()

        end_time = time.perf_counter()

        cpu = process.cpu_percent(None)

        end_memory = process.memory_info().rss / (1024 * 1024)

        elapsed = end_time - start_time

        memory_usage.append(end_memory)
        cpu_usage.append(cpu)

        print(
            f"Run {run_number:02d}: "
            f"{elapsed:.6f} sec | "
            f"CPU: {cpu:.2f}% | "
            f"Memory: {end_memory:.2f} MB"
        )

    print()
    print("=" * 60)
    print("RESOURCE USAGE RESULTS")
    print("=" * 60)

    print(
        f"Average CPU usage: "
        f"{statistics.mean(cpu_usage):.2f}%"
    )

    print(
        f"Maximum CPU usage: "
        f"{max(cpu_usage):.2f}%"
    )

    print(
        f"Average memory usage: "
        f"{statistics.mean(memory_usage):.2f} MB"
    )

    print(
        f"Maximum memory usage: "
        f"{max(memory_usage):.2f} MB"
    )

    print("=" * 60)


if __name__ == "__main__":
    run_resource_test()