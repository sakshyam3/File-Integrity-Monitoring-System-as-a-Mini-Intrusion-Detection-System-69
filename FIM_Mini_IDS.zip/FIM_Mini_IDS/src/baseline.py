import json
from pathlib import Path
import sys

# Get the main project folder
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Add src folder to Python path
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from hash_utils import calculate_sha256


MONITORED_FOLDER = PROJECT_ROOT / "monitored_files"
BASELINE_FOLDER = PROJECT_ROOT / "baseline"
BASELINE_FILE = BASELINE_FOLDER / "baseline.json"


def create_baseline():
    """
    Create a trusted baseline containing the SHA-256 hash
    of every file in the monitored folder.
    """

    BASELINE_FOLDER.mkdir(exist_ok=True)

    baseline = {}

    if not MONITORED_FOLDER.exists():
        print("ERROR: Monitored folder was not found.")
        print(f"Expected location: {MONITORED_FOLDER}")
        return

    for file_path in MONITORED_FOLDER.rglob("*"):
        if file_path.is_file():

            relative_path = str(
                file_path.relative_to(MONITORED_FOLDER)
            )

            baseline[relative_path] = {
                "sha256": calculate_sha256(file_path),
                "size": file_path.stat().st_size
            }

    with open(BASELINE_FILE, "w", encoding="utf-8") as file:
        json.dump(baseline, file, indent=4)

    print("=" * 60)
    print("FIM BASELINE CREATED")
    print("=" * 60)
    print(f"Monitored folder: {MONITORED_FOLDER}")
    print(f"Files recorded: {len(baseline)}")
    print(f"Baseline saved to: {BASELINE_FILE}")
    print()

    for file_name, details in baseline.items():
        print(f"File: {file_name}")
        print(f"SHA-256: {details['sha256']}")
        print(f"Size: {details['size']} bytes")
        print("-" * 60)


if __name__ == "__main__":
    create_baseline()