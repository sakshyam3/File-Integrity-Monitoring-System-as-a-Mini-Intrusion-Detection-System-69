import hashlib
from pathlib import Path


def calculate_sha256(file_path):
    """
    Calculate the SHA-256 hash of a file.
    """
    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:
        for block in iter(lambda: file.read(4096), b""):
            sha256.update(block)

    return sha256.hexdigest()


if __name__ == "__main__":
    test_file = Path("monitored_files/document1.txt")

    if test_file.exists():
        file_hash = calculate_sha256(test_file)

        print("File:", test_file)
        print("SHA-256:", file_hash)
    else:
        print("Test file not found:", test_file)