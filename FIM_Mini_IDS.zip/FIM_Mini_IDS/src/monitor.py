import json
from pathlib import Path
import sys

# Get the main project folder
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Add src folder to Python path
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from hash_utils import calculate_sha256
from logger import setup_logger

MONITORED_FOLDER = PROJECT_ROOT / "monitored_files"
BASELINE_FILE = PROJECT_ROOT / "baseline" / "baseline.json"

logger = setup_logger()

def load_baseline():
    """
    Load the trusted baseline from baseline.json.
    """
    if not BASELINE_FILE.exists():
        print("ERROR: Baseline file not found.")
        print(f"Expected location: {BASELINE_FILE}")
        return {}

    with open(BASELINE_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def scan_current_files():
    """
    Scan the monitored folder and calculate
    the current SHA-256 hash of every file.
    """
    current_files = {}

    for file_path in MONITORED_FOLDER.rglob("*"):
        if file_path.is_file():

            relative_path = str(
                file_path.relative_to(MONITORED_FOLDER)
            )

            current_files[relative_path] = {
                "sha256": calculate_sha256(file_path),
                "size": file_path.stat().st_size
            }

    return current_files


def detect_changes():
    """
    Compare the trusted baseline with the current
    file-system state.
    """

    baseline = load_baseline()
    current_files = scan_current_files()

    if not baseline:
        return

    baseline_files = set(baseline.keys())
    current_file_names = set(current_files.keys())

    modified_files = []
    new_files = []
    deleted_files = []

    # Check for modified and unchanged files
    for file_name in baseline_files & current_file_names:

        baseline_hash = baseline[file_name]["sha256"]
        current_hash = current_files[file_name]["sha256"]

        if baseline_hash != current_hash:
            modified_files.append(file_name)

    # Check for newly created files
    new_files = list(current_file_names - baseline_files)

    # Check for deleted files
    deleted_files = list(baseline_files - current_file_names)

    print("=" * 60)
    print("FIM INTEGRITY MONITORING RESULTS")
    print("=" * 60)

    if modified_files:
        print("\n[MODIFIED FILES]")
        for file_name in modified_files:
            print(f"  ALERT: {file_name}")

            logger.warning(
                f"MODIFIED FILE DETECTED | File: {file_name}"
            )

    else:
        print("\n[MODIFIED FILES]")
        print("  None detected.")

    if new_files:
        print("\n[NEW FILES]")
        for file_name in new_files:
            print(f"  ALERT: {file_name}")

            logger.warning(
                f"NEW FILE DETECTED | File: {file_name}"
            )

    else:
        print("\n[NEW FILES]")
        print("  None detected.")

    if deleted_files:
        print("\n[DELETED FILES]")
        for file_name in deleted_files:
            print(f"  ALERT: {file_name}")

            logger.warning(
                f"DELETED FILE DETECTED | File: {file_name}"
            )

    else:
        print("\n[DELETED FILES]")
        print("  None detected.")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    detect_changes()